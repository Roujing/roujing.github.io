(function () {
  'use strict';

  const root = document.documentElement;
  const storageKey = 'rw-theme';
  let storage = null;
  let preference = null;
  let systemTheme = null;
  let currentTheme;
  let printing = false;

  const isTheme = value => value === 'light' || value === 'dark';

  try {
    storage = window.localStorage;
    const saved = storage.getItem(storageKey);
    if (isTheme(saved)) preference = saved;
  } catch (_) {
    // The switch still works when browser privacy settings block storage.
  }

  try {
    if (window.matchMedia) {
      systemTheme = window.matchMedia('(prefers-color-scheme: dark)');
    }
  } catch (_) {
    // Browsers without a usable system preference start in light mode.
  }

  function resolvedTheme() {
    return preference || (systemTheme && systemTheme.matches ? 'dark' : 'light');
  }

  function applyTheme(theme) {
    currentTheme = theme;
    root.setAttribute('data-theme', theme);

    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', theme === 'dark' ? '#192126' : '#f7f5f0');

    const chinese = root.lang.toLowerCase().startsWith('zh');
    const dark = theme === 'dark';

    document.querySelectorAll('img[data-theme-light-src][data-theme-dark-src]').forEach(image => {
      const source = image.getAttribute(dark ? 'data-theme-dark-src' : 'data-theme-light-src');
      if (source && image.getAttribute('src') !== source) image.setAttribute('src', source);
    });
    document.querySelectorAll('a[data-theme-light-href][data-theme-dark-href]').forEach(link => {
      const target = link.getAttribute(dark ? 'data-theme-dark-href' : 'data-theme-light-href');
      if (target && link.getAttribute('href') !== target) link.setAttribute('href', target);
    });

    const action = chinese ? (dark ? '日间' : '夜间') : (dark ? 'Light' : 'Dark');
    const accessibleAction = chinese
      ? (dark ? '切换至日间模式' : '切换至夜间模式')
      : (dark ? 'Switch to light mode' : 'Switch to dark mode');

    document.querySelectorAll('[data-theme-toggle]').forEach(button => {
      button.setAttribute('aria-pressed', String(dark));
      button.setAttribute('aria-label', accessibleAction);
      const label = button.querySelector('[data-theme-label]');
      if (label) label.textContent = action;
    });
  }

  // This runs synchronously in the head, before the first paint.
  applyTheme(resolvedTheme());

  function bindToggles() {
    document.querySelectorAll('[data-theme-toggle]').forEach(button => {
      button.addEventListener('click', () => {
        if (printing) return;
        preference = currentTheme === 'dark' ? 'light' : 'dark';
        applyTheme(preference);
        try {
          if (storage) storage.setItem(storageKey, preference);
        } catch (_) {
          // Keep the manual choice in memory for this page visit.
        }
      });
    });
    // Also update controls or the theme-color meta parsed after this script.
    applyTheme(printing ? 'light' : resolvedTheme());
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bindToggles, { once: true });
  } else {
    bindToggles();
  }

  function onSystemChange() {
    if (!printing && !preference) applyTheme(resolvedTheme());
  }

  if (systemTheme) {
    if (systemTheme.addEventListener) {
      systemTheme.addEventListener('change', onSystemChange);
    } else if (systemTheme.addListener) {
      systemTheme.addListener(onSystemChange);
    }
  }

  window.addEventListener('storage', event => {
    if (event.key !== storageKey && event.key !== null) return;
    if (storage && event.storageArea && event.storageArea !== storage) return;
    preference = isTheme(event.newValue) ? event.newValue : null;
    if (!printing) applyTheme(resolvedTheme());
  });

  window.addEventListener('beforeprint', () => {
    printing = true;
    applyTheme('light');
  });

  window.addEventListener('afterprint', () => {
    printing = false;
    applyTheme(resolvedTheme());
  });
}());
