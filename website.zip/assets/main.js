document.querySelectorAll('[data-year]').forEach(node => { node.textContent = new Date().getFullYear(); });
const navigation = document.querySelector('.site-nav');
if (navigation && 'IntersectionObserver' in window) {
  const links = [...navigation.querySelectorAll('a[href^="#"]')];
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      links.forEach(link => {
        if (link.getAttribute('href') === '#' + entry.target.id) link.setAttribute('aria-current', 'location');
        else link.removeAttribute('aria-current');
      });
    });
  }, { rootMargin: '-10% 0px -65% 0px', threshold: 0 });
  links.forEach(link => { const section = document.querySelector(link.getAttribute('href')); if (section) observer.observe(section); });
}

document.querySelectorAll('[data-contact-form]').forEach(form => {
  const status = form.querySelector('.form-status');
  const button = form.querySelector('button[type="submit"]');
  const isChinese = document.documentElement.lang.startsWith('zh');
  const labels = isChinese ? {
    sending: '正在发送…',
    success: '谢谢，你的留言已提交。',
    activation: '留言服务正在等待收件人确认启用。请暂时直接发送至 roujing.wu2@unibo.it。',
    error: '暂时未能发送，请重试，或直接发送至 roujing.wu2@unibo.it。'
  } : {
    sending: 'Sending…',
    success: 'Thank you — your message has been submitted.',
    activation: 'The contact service is awaiting recipient activation. Please email roujing.wu2@unibo.it directly for now.',
    error: 'Your message could not be sent. Please try again or email roujing.wu2@unibo.it directly.'
  };
  form.addEventListener('submit', async event => {
    event.preventDefault();
    if (!form.reportValidity() || button.disabled) return;
    const data = Object.fromEntries(new FormData(form));
    if (data._honey) return;
    const previousLabel = button.innerHTML;
    button.disabled = true;
    button.textContent = labels.sending;
    form.setAttribute('aria-busy', 'true');
    status.textContent = labels.sending;
    status.dataset.state = 'sending';
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 25000);
    try {
      const response = await fetch('https://formsubmit.co/ajax/roujing.wu2@unibo.it', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify(data),
        signal: controller.signal
      });
      const result = await response.json();
      const accepted = result.success === true || result.success === 'true';
      if (/activat|confirm.{0,20}email|verify.{0,20}email/i.test(result.message || '')) {
        status.dataset.state = 'error';
        status.textContent = labels.activation;
      } else if (!response.ok || !accepted) {
        throw new Error('Submission was not accepted');
      } else {
        status.dataset.state = 'success';
        status.textContent = labels.success;
        form.reset();
      }
    } catch {
      status.dataset.state = 'error';
      status.textContent = labels.error;
    } finally {
      clearTimeout(timeout);
      form.removeAttribute('aria-busy');
      button.disabled = false;
      button.innerHTML = previousLabel;
      status.focus({ preventScroll: true });
    }
  });
});
