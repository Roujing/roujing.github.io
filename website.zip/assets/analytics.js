(function () {
  'use strict';

  const script = document.currentScript;
  const measurementId = script && (script.getAttribute('data-measurement-id') || '').trim();
  const production = window.location.hostname === 'roujing.github.io';
  const preview = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';
  if (!/^G-[A-Z0-9]{10}$/.test(measurementId) || (!production && !preview)) return;
  if (window.__rwAnalyticsInitialized) return;
  window.__rwAnalyticsInitialized = true;

  const storageKey = 'rw-analytics-consent';
  const disableKey = 'ga-disable-' + measurementId;
  const chinese = (document.documentElement.lang || '').toLowerCase().startsWith('zh');
  const denied = {
    analytics_storage: 'denied',
    ad_storage: 'denied',
    ad_user_data: 'denied',
    ad_personalization: 'denied'
  };
  const accepted = Object.assign({}, denied, { analytics_storage: 'granted' });
  const text = chinese ? {
    title: '可选的网站统计',
    explanation: '允许后，Google Analytics 将帮助我了解每日访问量、访客的大致国家或地区，以及网站参与时长。拒绝不会影响浏览。',
    allow: '允许统计',
    decline: '拒绝',
    settings: '统计设置',
    about: '关于网站统计',
    blocked: '已尊重浏览器的隐私信号：不会加载网站统计。',
    preview: '本地预览：此处不会加载或发送网站统计。'
  } : {
    title: 'Optional website analytics',
    explanation: 'If you allow it, Google Analytics helps me understand daily visits, approximate country or region, and engagement time. You can decline and use the site as usual.',
    allow: 'Allow analytics',
    decline: 'Decline',
    settings: 'Analytics settings',
    about: 'About analytics',
    blocked: 'Your browser privacy signal is respected: analytics will not load.',
    preview: 'Local preview: analytics is never loaded or sent here.'
  };

  let storage = null;
  let choice = null;
  let notice = null;
  let settingsButton = null;
  let returnFocus = false;
  let loaderStarted = false;
  let tagLoaded = false;
  let configured = false;
  window[disableKey] = true;

  const validChoice = value => value === 'granted' || value === 'denied';
  try {
    storage = window.localStorage;
    const saved = storage.getItem(storageKey);
    if (validChoice(saved)) choice = saved;
  } catch (_) {
    // A decision still works in memory when browser storage is unavailable.
  }

  function privacySignal() {
    const navigator = window.navigator || {};
    const dnt = String(navigator.doNotTrack || window.doNotTrack || navigator.msDoNotTrack || '').toLowerCase();
    return navigator.globalPrivacyControl === true || dnt === '1' || dnt === 'yes';
  }

  function allowed() {
    return production && choice === 'granted' && !privacySignal();
  }

  function sanitizedUrl(value) {
    if (!value) return '';
    try {
      const url = new URL(value, window.location.origin);
      return url.protocol === 'https:' || url.protocol === 'http:' ? url.origin + url.pathname : '';
    } catch (_) {
      return '';
    }
  }

  function clearAnalyticsCookies() {
    const cookieNames = ['_ga', '_ga_' + measurementId.slice(2)];
    const paths = new Set(['/']);
    const segments = window.location.pathname.split('/');
    let path = '';
    segments.forEach(segment => {
      if (!segment) return;
      path += '/' + segment;
      paths.add(path);
      paths.add(path + '/');
    });
    cookieNames.forEach(name => {
      paths.forEach(cookiePath => {
        ['', window.location.hostname, '.' + window.location.hostname].forEach(domain => {
          try {
            document.cookie = name + '=; Max-Age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Path=' + cookiePath +
              (domain ? '; Domain=' + domain : '') + '; SameSite=Lax' + (window.location.protocol === 'https:' ? '; Secure' : '');
          } catch (_) {
            // Cookie access can also be blocked by browser privacy settings.
          }
        });
      });
    });
  }

  function command() {
    if (typeof window.gtag === 'function') window.gtag.apply(window, arguments);
  }

  function configureAnalytics() {
    if (!allowed() || !tagLoaded || configured) return;
    configured = true;
    command('config', measurementId, {
      page_location: sanitizedUrl(window.location.href),
      page_referrer: sanitizedUrl(document.referrer),
      allow_google_signals: false,
      allow_ad_personalization_signals: false,
      cookie_domain: window.location.hostname,
      cookie_path: '/',
      cookie_flags: 'SameSite=Lax;Secure'
    });
  }

  function loadAnalyticsOnce() {
    if (!allowed()) return;
    window[disableKey] = false;
    if (loaderStarted) {
      command('consent', 'update', accepted);
      configureAnalytics();
      return;
    }
    loaderStarted = true;
    window.dataLayer = window.dataLayer || [];
    window.gtag = window.gtag || function () { window.dataLayer.push(arguments); };
    command('consent', 'default', denied);
    command('set', 'ads_data_redaction', true);
    command('set', 'url_passthrough', false);
    command('consent', 'update', accepted);
    command('js', new Date());

    const tag = document.createElement('script');
    tag.async = true;
    tag.src = 'https://www.googletagmanager.com/gtag/js?id=' + encodeURIComponent(measurementId);
    tag.referrerPolicy = 'strict-origin';
    tag.addEventListener('load', () => {
      tagLoaded = true;
      configureAnalytics();
    }, { once: true });
    tag.addEventListener('error', () => {
      // A blocked analytics service never prevents use of the website.
      window[disableKey] = true;
    }, { once: true });
    try {
      document.head.appendChild(tag);
    } catch (_) {
      window[disableKey] = true;
    }
  }

  function applyChoice() {
    if (allowed()) {
      loadAnalyticsOnce();
    } else {
      window[disableKey] = true;
      if (loaderStarted) command('consent', 'update', denied);
      clearAnalyticsCookies();
    }
  }

  function closeNotice() {
    if (notice) notice.remove();
    notice = null;
    if (returnFocus && settingsButton) settingsButton.focus();
    returnFocus = false;
  }

  function choose(value) {
    choice = value;
    try {
      if (storage) storage.setItem(storageKey, value);
    } catch (_) {
      // Keep the choice for this page even if it cannot be remembered.
    }
    applyChoice();
    closeNotice();
  }

  function showNotice(fromSettings) {
    if (notice) return;
    returnFocus = Boolean(fromSettings);
    notice = document.createElement('section');
    notice.className = 'analytics-notice';
    notice.setAttribute('role', 'region');
    notice.setAttribute('aria-labelledby', 'analytics-notice-title');

    const title = document.createElement('h2');
    title.id = 'analytics-notice-title';
    title.textContent = text.title;
    notice.appendChild(title);
    const explanation = document.createElement('p');
    explanation.textContent = text.explanation;
    notice.appendChild(explanation);

    const about = document.createElement('a');
    about.href = 'privacy.html#analytics';
    about.textContent = text.about;
    notice.appendChild(about);
    if (privacySignal() || preview) {
      const note = document.createElement('p');
      note.className = 'analytics-note';
      note.textContent = privacySignal() ? text.blocked : text.preview;
      notice.appendChild(note);
    }

    const actions = document.createElement('div');
    actions.className = 'analytics-actions';
    const allow = document.createElement('button');
    allow.type = 'button';
    allow.textContent = text.allow;
    allow.disabled = privacySignal();
    allow.addEventListener('click', () => choose('granted'));
    const decline = document.createElement('button');
    decline.type = 'button';
    decline.textContent = text.decline;
    decline.addEventListener('click', () => choose('denied'));
    actions.appendChild(allow);
    actions.appendChild(decline);
    notice.appendChild(actions);
    document.body.appendChild(notice);
  }

  function initialize() {
    const footer = document.querySelector('.site-footer .footer-inner');
    if (footer) {
      settingsButton = document.createElement('button');
      settingsButton.type = 'button';
      settingsButton.className = 'analytics-settings';
      settingsButton.textContent = text.settings;
      settingsButton.addEventListener('click', () => showNotice(true));
      footer.appendChild(settingsButton);
    }
    if (choice === null && !privacySignal()) showNotice(false);
  }

  // No Google tag or third-party request exists before an affirmative choice.
  applyChoice();
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialize, { once: true });
  } else {
    initialize();
  }
  window.addEventListener('storage', event => {
    if (event.key !== storageKey && event.key !== null) return;
    choice = validChoice(event.newValue) ? event.newValue : null;
    applyChoice();
    closeNotice();
    if (choice === null && !privacySignal()) showNotice(false);
  });
}());
